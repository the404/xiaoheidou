var $url = 'http://wx.ipow.cn/activity/qrcode/GetQrCode?callback=?';
var $groupId, $num;
$.ajax({
    url: $url,
    dataType: "jsonp",
    success: function (data) {
        console.log(data)
        $('#scanImg').attr('src', data.Url);
        $groupId = data.UserId;
        $num = data.Num;
    }
}).done(function () {
    jQuery.support.cors = true;
    LinkSignalr();
});

function LinkSignalr() {
    $.getScript('http://wx.ipow.cn/Scripts/jquery.signalR-2.2.0.min.js', function () {
        $.getScript('http://wx.ipow.cn/Scripts/hubs.js').done(function () {
            $.connection.hub.url = "http://localhost:34466/signalr";
            var myHub = $.connection.awardHub;

            myHub.client.startAward = function (awardNum) {
                startAward(awardNum);
            }
            $.connection.logging = true;
            $.connection.hub.start().done(function () {

            });
        });
    });
};

var iNow = 0;                               //当前值
iCount = $(".lottery-tab td").length - 1, //中奖的总个数
iSpeed = 100,                           //速度
iCycle = 60,                            //至少步数
iStepNow = 0,                           //当前步
timer = null,                           //定时器
iKey = 0,                               //中奖值
bMove = true,                           //是否在抽奖
arrLottery = [];                        //中奖数组

for (var i = 0; i < iCount; i++) {
    arrLottery.push($(".tab-" + i)[0]);// 排序数组
};
function startAward(num) {
    if (bMove) {
        iKey = num;
        setClass();
        bMove = false;
    };
    return false;
}
function setClass() {
    iNow++;
    iStepNow++;
    if (iStepNow == iCycle + iKey) {
        clearTimeout(timer);
        iSpeed = 100;
        iStepNow = 0;
        iNow = 0;
        setTimeout(function () {
            bMove = true;
            awardShow(iNow);
        }, 200);
    } else {
        if (iStepNow < iCycle + iKey - 10) {
            iSpeed -= 10;       //加速
        } else if (iStepNow > iCycle + iKey - 10) {
            iSpeed += 70;       //减速
            if (iSpeed > 500) {
                iSpeed = 500;   //结尾固定减速
            };
        };
        if (iNow >= iCount) {
            iNow = 0;           //超过还原值;
        };
        if (iSpeed < 40) {
            iSpeed = 40;        //中间固定速度;
        };
        $(arrLottery).removeClass("focus");
        $(arrLottery).eq(iNow).addClass("focus");
        timer = setTimeout(setClass, iSpeed);
    };
};

var awardText;
function awardShow(num) {
    awardText = $(arrLottery).eq(num - 1).text();
    $(".award-info").text(awardText);
    $(".award-wrap").show();
    $(".award-wrap").bind("click", function (e) {
        $(this).hide();
        return false;
    });
};